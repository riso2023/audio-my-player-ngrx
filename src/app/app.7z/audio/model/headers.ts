export interface HeadersDTO {
  status: string;
  code: number;
  error_message: string;
  warnings: string;
  results_count: number;
}
