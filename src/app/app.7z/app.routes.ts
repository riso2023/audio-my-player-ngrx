import { Routes } from '@angular/router';
import {AudioContainerComponent} from "./audio/components/audio-container/audio-container.component";

export const routes: Routes = [
  { path: '', component: AudioContainerComponent }
];
